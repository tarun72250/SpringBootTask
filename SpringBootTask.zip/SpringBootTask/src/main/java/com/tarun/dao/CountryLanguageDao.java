package com.tarun.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.tarun.entities.CountryLanguage;

public interface CountryLanguageDao extends JpaRepository<CountryLanguage, Integer> {

	@Query("SELECT cl FROM CountryLanguage cl WHERE cl.countryCode =:countryCode ORDER BY cl.percentage DESC")
    List<CountryLanguage> getByCountryCodeOrderByPercentageDesc(@Param("countryCode") String countryCode);
	
	@Query("SELECT cl FROM CountryLanguage cl WHERE cl.language =:langauge ORDER BY cl.percentage DESC")
	List<CountryLanguage> getByCountryLanguageOrderByPercentageDesc(@Param("langauge") String langauge);
}
