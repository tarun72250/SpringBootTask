package com.tarun.util;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.opencsv.CSVReader;
import com.tarun.entities.CountryLanguage;

@Service
public class CsvService {

	public List<CountryLanguage> readCsvAndReturnList() {
		List<CountryLanguage> list = new ArrayList<>();
		try{
			CSVReader csvReader = new CSVReader(new FileReader("C:\\Users\\gopal\\Downloads\\countrylanguage.csv"));
//			System.out.println(csvReader.readAll());
            List<String[]> records = csvReader.readAll();
            for (String[] record : records) {
            	for (String strings : record) {
					System.out.println(strings);
				}
            	System.out.println("=======================================");
//            	CountryLanguage countryLanguage = new CountryLanguage();
//            	countryLanguage.setCountryCode(record[0]);
//            	countryLanguage.setLanguage(record[1]);
//            	countryLanguage.setIsOfficial(record[2]);
//            	countryLanguage.setPercentage(Double.parseDouble(record[3]));
//            	list.add(countryLanguage);
            }
		}catch (Exception e) {
			e.printStackTrace();
		}	
		return list;
	}
}
