package com.tarun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDay16RestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDay16RestApiApplication.class, args);
	} 
}
