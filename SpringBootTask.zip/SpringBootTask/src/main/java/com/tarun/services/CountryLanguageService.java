package com.tarun.services;

import java.util.List;

import com.tarun.entities.CountryLanguage;


public interface CountryLanguageService {

	/*
	 * To get the list of country
	 */
	public List<CountryLanguage> getCountryLanguage();
		
	/*
	 * To get the country by CountryCode
	 */
	public List<CountryLanguage> getCountryByCountryLanguage(String language);
	
	/*
	 * To get the country by CountryCode
	 */
	public List<CountryLanguage> getOfficialLangaugeByCountryCode(String countryCode);
	
	/*
	 * To add the country
	 */
	public CountryLanguage addCountryLanguage(CountryLanguage countryLanguage);

}
