package com.tarun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDay16RestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
